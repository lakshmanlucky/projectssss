﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace ABCBANKDAL
{
    class Datautilitycs
    {
        public static String getConnection()
        {
            String str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            return str;
        }


    }
}
