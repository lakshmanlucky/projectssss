﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Types;
using ABCBANKBOFACTORY;




namespace ABCBANKDAL
{
    public class CustomerDAL:ICustomerDAL
    {
        public int AddCustomer(ICustomerBO objcust)
        {
                int ret = 0;


                SqlConnection conn = new SqlConnection();
                   
                //string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                try
                {
                    conn.ConnectionString = Datautilitycs.getConnection();
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.CommandText = "sp_AddCustomer";

                    cmd.Parameters.AddWithValue("@custname", objcust.CustomerName);
                    cmd.Parameters.AddWithValue("@custdob", objcust.DOB);
                    cmd.Parameters.AddWithValue("@custbranchid", objcust.BranchID);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Connection = conn;
                    ret = cmd.ExecuteNonQuery();
                    conn.Close();
                    return ret;
                }
                catch
                {
                    throw;
                }
            

        }


        public int updateCustomer(ICustomerBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;
            
            string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "sp_updateCustomer";
            cmd.Parameters.AddWithValue("@custid", objcust.CustomerID);
            cmd.Parameters.AddWithValue("@custname", objcust.CustomerName);
            cmd.Parameters.AddWithValue("@custdob",  objcust.DOB);
            cmd.Parameters.AddWithValue("@custbranchid", objcust.BranchID);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            ret = cmd.ExecuteNonQuery();
            conn.Close();
            return ret;

        }


        public int DeleteCustomer(ICustomerBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;
                     

            string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "sp_deleteCustomer";
            cmd.Parameters.AddWithValue("@custid", objcust.CustomerID);
           

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            ret = cmd.ExecuteNonQuery();
            conn.Close();
            return ret;

        }


        public DataTable ViewCustomers()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            SqlDataAdapter da = new SqlDataAdapter();

            string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "sp_viewCustomers";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            da.SelectCommand = cmd;
            da.Fill(dt);
            conn.Close();
            return dt;

        }


        public ICustomerBO ViewCustomer(int customerID)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();
            ICustomerBO objCustomerBO = null;
            SqlDataAdapter da = new SqlDataAdapter();
            
            string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "sp_viewCustomer";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            da.SelectCommand = cmd;
            da.Fill(dt);
            conn.Close();
            if (dt.Rows.Count > 0)
            {
                
                string customerName=dt.Rows[0]["CustomerName"].ToString();
                int branchID=int.Parse(dt.Rows[0]["branchID"].ToString());
                objCustomerBO = ABCBANKBOFACTORY.CustomerBOFactory.CreateCustomerBO(customerID,customerName,branchID);
            }
            return objCustomerBO;

        }


    }
}
