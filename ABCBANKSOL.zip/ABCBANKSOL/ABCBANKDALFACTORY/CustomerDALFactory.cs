﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ABCBANKDAL;
using Types;

namespace ABCBANKDALFACTORY
{
    public class CustomerDALFactory
    {
        public static ICustomerDAL CreateCustomerDAL()
        {
            ICustomerDAL objcustDAL = new CustomerDAL();
            return objcustDAL;
        }

    }
}
