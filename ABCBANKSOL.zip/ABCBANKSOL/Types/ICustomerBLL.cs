﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;


namespace Types
{
    public interface ICustomerBLL
    {
          int AddCustomer(ICustomerBO obj);
         int UpdateCustomer(ICustomerBO obj);
          int DeleteCustomet(ICustomerBO obj);
          DataTable ViewCustomers();
          ICustomerBO ViewCustomer(int customerID);
    }
}
