﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace ConsoleApplication3
{
    public class DBClass
    {

        static SqlConnection cn;
        static SqlCommand cmd;

        /// <summary>
        /// Creates a Connection with the Database
        /// </summary>
        /// <returns></returns>
        static SqlConnection GetConnection()
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN35_MMS206;User ID=mms206user;Password=mms206user";
            try
            {
                if (!string.IsNullOrEmpty(conStr))
                {
                    return new SqlConnection(conStr);
                }
                else
                    return null;
            }
            catch
            {
                return null;
            }
        }

        public static int AddStudent(Student objstudent)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }

            cmd = new SqlCommand("usp_AddStudent", cn); cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@name", objstudent.StudentName));
            cmd.Parameters.Add(new SqlParameter("@marks", objstudent.Marks));
            SqlParameter stdNoParam = cmd.Parameters.Add("@stdid", SqlDbType.Int);
            stdNoParam.Direction = ParameterDirection.Output;
            int i = cmd.ExecuteNonQuery();
            cn.Close();
            if (i > 0)
            {
                return (int)stdNoParam.Value;
            }
            return 0;
        }


        public static Student SearchStudent(int StdNo)
        {
            Student objstudent = new Student();
            
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }
            
            cmd = new SqlCommand("usp_GetStudentInfo", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@id", StdNo);
            //cmd.Parameters.Add(new SqlParameter("@id", empNo));
            SqlDataReader stdReader = cmd.ExecuteReader();
            if (stdReader.Read())
            {
                objstudent.StudentName = stdReader[1].ToString(); //empReader["Name"].ToString() or empReader.GetValue(1).ToString();
                objstudent.Marks = Convert.ToInt32(stdReader[2].ToString());
                objstudent.Studentid = StdNo;
            
            }
            return objstudent;
            
        }

        public static bool ModifyStudent(Student objStudent)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }

            cmd = new SqlCommand("usp_ModifyStudent", cn); 
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@id", objStudent.Studentid));
            cmd.Parameters.Add(new SqlParameter("@name",objStudent.StudentName));
            cmd.Parameters.Add(new SqlParameter("@marks", objStudent.Marks));
            int result=cmd.ExecuteNonQuery();
            cn.Close();
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        public static bool RemoveStudent(int stdNo)
        {
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }
            cmd = new SqlCommand("usp_DeleteStudent", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add(new SqlParameter("@id", stdNo));
            int result=cmd.ExecuteNonQuery();
            cn.Close();
            if (result > 0)
            {
                return true;
            }
            return false;
        }

        //public static List<Student> ViewStudents()
        //{

        //    List<Student> lstStudent = new List<Student>();
        //    cn = GetConnection();
        //    if (cn.State == System.Data.ConnectionState.Closed)
        //    {
        //        cn.Open();
        //    }

        //    cmd = new SqlCommand("usp_GetStudentsInfo", cn);
        //    cmd.CommandType = CommandType.StoredProcedure;
        //    DataSet dsstudent=new DataSet();

        //    SqlDataAdapter stdadapter = new SqlDataAdapter();
        //    stdadapter.Fill(dsstudent);
            
        //    foreach(DataRow dr in dsstudent.Tables[0].Rows)
        //    {
        //        Student objStudent = new Student();
        //        objStudent.Studentid = Convert.ToInt32(dr["StdID"].ToString());
        //        objStudent.StudentName = dr["StdName"].ToString();
        //        objStudent.Marks = Convert.ToInt32(dr["Marks"].ToString());
        //        lstStudent.Add(objStudent);


        //    }
        //    return lstStudent;

        //}

        public static List<Student> ViewStudents()
        {

            List<Student> lstStudent = new List<Student>();
            cn = GetConnection();
            if (cn.State == System.Data.ConnectionState.Closed)
            {
                cn.Open();
            }

            cmd = new SqlCommand("usp_GetStudentsInfo", cn);
            cmd.CommandType = CommandType.StoredProcedure;
            

            SqlDataReader stdReader = cmd.ExecuteReader();
            while (stdReader.Read())
            {

                Student objStudent = new Student();
                objStudent.Studentid = Convert.ToInt32(stdReader["StdID"].ToString());
                objStudent.StudentName = stdReader["StdName"].ToString();
                objStudent.Marks = Convert.ToInt32(stdReader["Marks"].ToString());
                lstStudent.Add(objStudent);


            }
            return lstStudent;

        }
        




    }
}
