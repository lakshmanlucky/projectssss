﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace WebApplication7
{
    public partial class UpdateBus : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                populateSource();
                ddlDestination.Items.Insert(0, "Select");
            }
        }

        protected void btnFind_Click(object sender, EventArgs e)
        {
            SqlConnection cn;
            SqlCommand cmd;

            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            cn = new SqlConnection();
            try
            {

                cn.ConnectionString = conStr;
                cn.Open();
                cmd = new SqlCommand("sp_Findbus", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@busid", txtBusID.Text));


                SqlDataReader dr = cmd.ExecuteReader();
                while(dr.Read())
                {
                   
                    ddlSource.Text = dr["source"].ToString();
                    populateDestination();
                    ddlDestination.Text = dr["destination"].ToString();
                    txtPrice.Text = dr["price"].ToString();

                }
                cn.Close();
                
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
        }

        protected void btnAdd_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlConnection cn;

            string conStr = System.Configuration.ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            cn = new SqlConnection();
            try
            {

                cn.ConnectionString = conStr;
                cn.Open();
                cmd = new SqlCommand("sp_updatebus", cn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter("@busid", txtBusID.Text));
                cmd.Parameters.Add(new SqlParameter("@destination", ddlDestination.Text));
                cmd.Parameters.Add(new SqlParameter("@source", ddlSource.Text));
                cmd.Parameters.Add(new SqlParameter("@price", int.Parse(txtPrice.Text)));


                int i = cmd.ExecuteNonQuery();
                cn.Close();
                if (i > 0)
                {
                    Response.Write("Updated sucessfully");
                    
                }
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (cn.State == ConnectionState.Open)
                    cn.Close();
            }
        }

        private void populateSource()
        {
            ddlSource.Items.Clear();
            ddlSource.Items.Add("Chennai");
            ddlSource.Items.Add("Madurai");
            ddlSource.Items.Add("Trichy");
            ddlSource.Items.Insert(0, "Select");

        }

        private void populateDestination()
        {
            ddlDestination.Items.Clear();
            if (ddlSource.Text == "Chennai")
            {

                ddlDestination.Items.Add("Madurai");
                ddlDestination.Items.Add("Trichy");
            }
            else if (ddlSource.Text == "Madurai")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Trichy");

            }
            else if (ddlSource.Text == "Trichy")
            {
                ddlDestination.Items.Add("Chennai");
                ddlDestination.Items.Add("Madurai");
            }
            else 
            {
                ddlDestination.Items.Insert(0, "Select");
            }
            


        }

        protected void ddlSource_SelectedIndexChanged(object sender, EventArgs e)
        {

            populateDestination();

        }
    }
}