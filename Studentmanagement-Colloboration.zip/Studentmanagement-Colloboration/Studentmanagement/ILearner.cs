﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studentmanagement
{
    interface ILearner
    {
         int LearnerID { get;set;}
         string LearnerName { get;set;} 
         Address LearnerAddress { get;set;}
         void getMarks();
         void printMarks();


    }
}
