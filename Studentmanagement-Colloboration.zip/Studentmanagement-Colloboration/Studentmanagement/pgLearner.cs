﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studentmanagement
{
    class pgLearner:Learner
    {
        int hsMarks;
        int ugMarks;

        public int HSMarks
        {
            get
            {
                return hsMarks;

            }

            set
            {
                hsMarks = value;

            }

        }

        public int UGMarks
        {
            get
            {
                return ugMarks;
            }

          
            set
            {
                ugMarks = value;

            }
        }

        public pgLearner(int learnerid,string learnername,Address objaddress)
        {


            LearnerID = learnerid;
            LearnerName = learnername;
            LearnerAddress = objaddress;

        }

        public override void getMarks()
        {
            try
            {

                int marks;
                Console.WriteLine("Enter hsMarks");
                marks = int.Parse(Console.ReadLine());
                if (marks < 0)
                {
                    throw new Exception("Marks should not be less than 0;");

                }
                hsMarks = marks;
                Console.WriteLine("Enter ugMarks");
                marks = int.Parse(Console.ReadLine());
                if(marks<0)
                {
                    throw new Exception("Marks should not be less than 0;");

                }
                ugMarks = marks;

            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

            

        }

        public override void printMarks()
        {
            


                Console.WriteLine("Higher Secondary Marks:");
                Console.WriteLine(hsMarks);

                Console.WriteLine("UG Marks:");
                Console.WriteLine(ugMarks);

        }


    }
}
