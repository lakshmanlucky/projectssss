﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class cookis : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Unnamed5_Click(object sender, EventArgs e)
        {

        }

        protected void Login_Click(object sender, EventArgs e)
        {
            Response.Cookies["Username"].Value = txtuser.Text;
            HttpCookie usercookie = new HttpCookie("usrname");
            usercookie.Value = txtuser.Text;
            Response.Cookies.Add(usercookie);
            Response.Cookies["Username"].Expires = DateTime.Now.AddDays(1);
           


            Session["username"] = txtuser.Text;
            Response.Redirect("homepage.aspx");
        }

        
    }
}