﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class querystringex : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!Page.IsPostBack)
            {

                DropDownList1.Items.Add("Product1");
                DropDownList1.Items.Add("Product2");
                DropDownList1.Items.Add("Product3");

                DropDownList1.Items.Add("Product4");

            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.Text != "Product1")
            {
                Response.Redirect("ViewDetails.aspx?product=" + DropDownList1.Text + "&prod=" + DropDownList1.Text);
            }
            else
            {
                Response.Redirect("ViewDetails.aspx?prod=" + DropDownList1.Text);
            }
        }
    }
}