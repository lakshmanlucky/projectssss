﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class ViewDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["product"] != null)
            {
                Response.Write("The details of " + Request.QueryString["product"]);
            }

            if (Request.QueryString["prod"] != null)
            {
                Response.Write("Details:  " + Request.QueryString["prod"]);
            }

        }
    }
}