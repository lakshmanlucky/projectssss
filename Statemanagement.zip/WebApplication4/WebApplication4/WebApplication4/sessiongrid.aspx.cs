﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace WebApplication4
{
    public partial class sessiongrid : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["product"] != null)
            {
                product objproduct = (product)Session["product"];
                Response.Write("Productid=");
                Response.Write(objproduct.ID);
                Response.Write("<BR>");
                Response.Write("Productname=");

                Response.Write(objproduct.Name);
            }




        }
    }
}