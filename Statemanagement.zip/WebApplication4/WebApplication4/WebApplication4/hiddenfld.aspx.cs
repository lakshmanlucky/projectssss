﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class hiddenfld : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int total;
            if (HiddenField1.Value!=string.Empty)
            { 
            total = int.Parse(TextBox1.Text) + int.Parse(HiddenField1.Value);
            }
            else
            {
                total = int.Parse(TextBox1.Text);
            }
            HiddenField1.Value = total.ToString();
            TextBox1.Text = total.ToString();
        }
    }
}