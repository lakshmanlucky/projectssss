﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            List<product> productLst = new List<product>();
            product objproduct = new product();
            objproduct.ID = 1;
            objproduct.Name = "product1";
            productLst.Add(objproduct);

            objproduct = new product();
            objproduct.ID = 2;
            objproduct.Name = "product2";

            GridView1.DataSource = productLst;
            GridView1.DataBind();
        }
    }
}