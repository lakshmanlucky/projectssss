--1. Create Employee Details and Leave Details Table

create table tblEmployeeDetails_LayeringDemo(
	EmployeeID int not null,
	Name varchar(30) not null,
	Status bit default 1 check (Status in(0,1))
)

create table tblLeaveDetails_LayeringDemo(
		LeaveID numeric(7) not null identity(1000330,1),
		EmployeeID int not null,
		LeaveType varchar(50) check (LeaveType in('Sick ','Casual','Earned','LOP')),
		FromDate date check(datediff(dd,getdate(),fromdate)>=0 and datediff(dd,getdate(),fromdate)<=90),
		ToDate date,
		ContactNo numeric(10) check(len(contactno)=10),
		Comments varchar(150),
		LeaveStatus varchar(50) DEFAULT 'PENDING' check(LeaveStatus in('Pending','Cancelled','Approved','Rejected')))


--select getdate()

--select datediff(dd,getdate(),'07-08-2016')

--select datediff(dd,getdate(),'10-10-2016')

INSERT INTO tblEmployeeDetails_LayeringDemo VALUES(12345,'John',1);
INSERT INTO tblEmployeeDetails_LayeringDemo VALUES(23456,'Stephen',0);
INSERT INTO tblEmployeeDetails_LayeringDemo VALUES(22345,'Clark',1);
INSERT INTO tblEmployeeDetails_LayeringDemo VALUES(11234,'Thomas',6);
INSERT INTO tblEmployeeDetails_LayeringDemo(EmployeeID,Name) VALUES(21445,'Jim')

INSERT INTO tblLeaveDetails_LayeringDemo VALUES(12345,'SICK','7/11/2016','7/11/2016',9492078814,'Fever and Body Pains','PENDING')


select * from tblEmployeeDetails_LayeringDemo

select * from tblLeaveDetails_LayeringDemo



--2.1 Primary Key on EmployeeID 

Alter table tblEmployeeDetails_LayeringDemo
Add Primary key (EmployeeID)

--2.2 Foreign Key on EmployeeID of LeaveDetails Table

Alter table tblLeaveDetails_LayeringDemo with nocheck
add foreign key(EmployeeID) references  tblEmployeeDetails_LayeringDemo(EmployeeID)


--Procedure for Applying Leave
Create Procedure usp_ApplyLeave_LayeringDemo
    @EmployeeID int ,
	@LeaveType varchar(50),
	@FromDate date,
	@ToDate date,
	@ContactNo bigint,
	@Comments varchar(150),
	@LeaveStatus varchar(50),
	@LeaveID numeric(7) OUT
AS
BEGIN
  if ((select Count(*) from tblEmployeeDetails_LayeringDemo where EmployeeID=@EmployeeID)>0)
  begin
      INSERT INTO tblLeaveDetails_LayeringDemo VALUES               (@EmployeeID,@LeaveType,@FromDate,@ToDate,@ContactNo,@Comments,@LeaveStatus)
	  set @LeaveID=@@IDENTITY
  end
  else
    set @LeaveID=0
END


--Procedure for Viewing Leave Details
Create Procedure usp_ViewLeaves_LayeringDemo
as
begin
  Select * from tblLeaveDetails_LayeringDemo
end



--Procedure for getting Employee IDs
alter Procedure usp_GetEmployeeIDs_LayeringDemo
as
begin
  Select EmployeeID from tblEmployeeDetails_LayeringDemo where status=1
end


exec usp_GetEmployeeIDs_LayeringDemo


--Procedure for Modifying Leave
Create Procedure usp_ModifyLeave
(
	@LeaveID numeric(7),    
	@LeaveType varchar(50),
	@FromDate date,
	@ToDate date,	
	@Comments varchar(150),
	@LeaveStatus varchar(50),
	@status int out
)
AS
BEGIN
  if ((select Count(*) from tblLeaveDetails_LayeringDemo where LeaveID=@LeaveID)>0)
  begin
      update tblLeaveDetails_LayeringDemo set
	  LeaveType=@LeaveType,
	  FromDate=@FromDate,
	  todate=@todate,
	  Comments=@Comments,
	  LeaveStatus=@LeaveStatus
	  where LeaveID=@LeaveID
	  set @status=1
  end
  else
    set @status=0
END


--Procedure for Removing Leave Details
Create Procedure usp_RemoveLeaveDetails
(
	@LeaveID numeric(7), 	
	@status int out
)
AS
BEGIN
  if ((select Count(*) from tblLeaveDetails_LayeringDemo where LeaveID=@LeaveID)>0)
  begin
      delete tblLeaveDetails_LayeringDemo 
	  where LeaveID=@LeaveID
	  set @status=1
  end
  else
    set @status=0
END