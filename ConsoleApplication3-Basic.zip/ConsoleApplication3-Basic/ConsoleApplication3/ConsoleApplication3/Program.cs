﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {

            int id;
            int marks;
            string name;

            Console.WriteLine("Please Enter studentid");
            id = int.Parse(Console.ReadLine());
            Console.WriteLine("Please Enter studentname");
            name = Console.ReadLine();
            Console.WriteLine("Please Enter marks");
            marks = int.Parse(Console.ReadLine());

            Student objstudent = new Student();

            objstudent.Studentid = id;
            objstudent.StudentName = name;
            objstudent.Marks = marks;

            objstudent.displayGrade();
            Console.ReadLine();


        }
    }
}
