﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using studentbo;
using stdenentdal;
using System.Data;

namespace stbll
{
    public class stdbll
    {

        public int AddStudent(studbo objbo)
        {
            stddal objclass = new stddal();
            return objclass.AddStudent(objbo);
        }

        public void DeleteStudent(int studeid)
        {
            stddal objclass = new stddal();
            objclass.DeleteStudent(studeid);


        }

        public void updateStudent(studbo objbo)
        {
            stddal objclass = new stddal();
            objclass.updateStudent(objbo);


        }



        public DataTable ViewStudent()
        {
            DataTable dt;
            stddal objclass = new stddal();

            dt= objclass.ViewStudent();

            dt.Columns.Add("Status");

            foreach (DataRow dr in dt.Rows)
            {
                if (dr["Active"].ToString() == "1")
                {
                    dr["Status"] = "Active";

                }
                else
                {
                    dr["Status"] = "InActive";
                }

            }

            dt.Columns.Remove("Active");



            return dt;
        }

        public string LoginStudent(string userid, string password)
        {
            stddal objclass = new stddal();
            return objclass.LoginStudent(userid, password);
        }



    }
}
