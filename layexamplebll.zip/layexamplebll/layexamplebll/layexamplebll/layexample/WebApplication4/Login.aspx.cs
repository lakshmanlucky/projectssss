﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using  stbll;

namespace WebApplication4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            stdbll objbll = new stdbll();

            string dept=objbll.LoginStudent(Textbox1.Text,Textbox2.Text);

            Session["DEPT"]=dept;

            if (dept == string.Empty)
            {
                Response.Write("Invalid Login credentails");
            }
            else
            {
                Response.Redirect("Add.aspx");
               
            }

        }
    }
}