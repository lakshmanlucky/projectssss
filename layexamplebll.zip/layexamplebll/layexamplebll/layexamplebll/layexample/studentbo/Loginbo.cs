﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace studentbo
{
    class Loginbo
    {
        string userid;
        string role;
        string password;








    }
}
