﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace studentbo
{
    public class studbo
    {
        int id;
        string password;
        string status;

        public int ID
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Password
        {
            get 
            {
                return password;
            }

            set
            {
                password = value;
            }
        }



        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }


    }
}
