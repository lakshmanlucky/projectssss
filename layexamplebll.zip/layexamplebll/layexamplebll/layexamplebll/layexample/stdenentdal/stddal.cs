﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using studentbo;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace stdenentdal
{
    public class stddal
    {

        public int AddStudent(studbo objstud)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;

            try
            {

                string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "Insert into studentlayer(id,password) values(@id,@password)";
                cmd.Parameters.AddWithValue("@id", objstud.ID);
                cmd.Parameters.AddWithValue("@password", objstud.Password);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                ret = cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (SqlException sqlex)
            {


                if (sqlex.Message.Contains("PRIMARY KEY"))
                {
                    ret= -2;
                }
                else
                {
                    ret= -1;
                }

            }
            catch (Exception e)
            {
                ret= -1;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            }
            return ret;

        }


        public int updateStudent(studbo objstud)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;

            try
            {

                string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "update student set status=@status where id=@id";
                cmd.Parameters.AddWithValue("@id", objstud.ID);
                cmd.Parameters.AddWithValue("@status", objstud.Status);
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                ret = cmd.ExecuteNonQuery();
                conn.Close();

            }
            catch (SqlException sqlex)
            {


                if (sqlex.Message.Contains("PRIMARY KEY"))
                {
                    ret = -2;
                }
                else
                {
                    ret = -1;
                }

            }
            catch (Exception e)
            {
                ret = -1;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }

            }
            return ret;

        }



           public void DeleteStudent(int studeid)
        {
            ////SqlConnection
            ////    SqlAdopter
            ////    cd.Pamater.Ad("@name,objstud.name)

        }

           public DataTable ViewStudent()
           {
               DataTable dt = new DataTable();
               SqlConnection conn = new SqlConnection();
               
               try
               {
                   SqlDataAdapter da = new SqlDataAdapter();

                   string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                   conn.ConnectionString = str;
                   conn.Open();
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "Select * from studentlayer";
                   cmd.CommandType = CommandType.Text;
                   cmd.Connection = conn;
                   da.SelectCommand = cmd;
                   da.Fill(dt);
                   conn.Close();
                   return dt;
               }
               catch (Exception ex)
               {
                   return null;
               }
               finally
               {
                   if (conn.State == ConnectionState.Open)
                   {
                       conn.Close();
                   }
               }

           }


           public string LoginStudent(string userid,string password)
           {
               DataTable dt = new DataTable();
               SqlConnection conn = new SqlConnection();

               try
               {
                   SqlDataAdapter da = new SqlDataAdapter();

                   string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                   conn.ConnectionString = str;
                   conn.Open();
                   SqlCommand cmd = new SqlCommand();
                   cmd.CommandText = "Select dept from studentlayer where id=@userid and password=@password";
                   cmd.CommandType = CommandType.Text;
                   cmd.Parameters.AddWithValue("@userid", userid);
                   cmd.Parameters.AddWithValue("@password",password);
                   cmd.Connection = conn;
                   da.SelectCommand = cmd;
                   da.Fill(dt);
                   conn.Close();
                   if (dt.Rows.Count == 0)
                   {
                       return string.Empty;
                   }
                   else
                   {
                       return dt.Rows[0]["dept"].ToString();
                   }
                   
                   
               }
               catch (Exception ex)
               {
                   return null;
               }
               finally
               {
                   if (conn.State == ConnectionState.Open)
                   {
                       conn.Close();
                   }
               }

           }


    }
}
