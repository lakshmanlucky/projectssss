﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using  stbll;
using Types;
using studentbo;

namespace WebApplication4
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            IStudentBLL objbll = new stdbll();
            ILoginBO objbo = new Loginbo();
            objbo.Userid = txtUserID.Text;
            objbo.Password = txtPassword.Text;

            string active = objbll.LoginStudent(objbo);
            Session["UserID"] = txtUserID.Text;
                
            

            if (active == string.Empty || active=="0")
            {
                Response.Write("Invalid Login credentails");
            }
            else
            {
                Response.Redirect("UserHome.aspx");
               
            }

        }
    }
}