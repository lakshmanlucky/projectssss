﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace studentbo
{
    public class Loginbo: ILoginBO
    {
        string userid;
        string role;
        string password;

        public string Userid
        {
            get
            {
                return userid;
            }

            set
            {
                userid = value;
            }
        }


        public string Role
        {
            get
            {
                return role;
            }

            set
            {
                role = value;
            }
        }


        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }





    }
}
