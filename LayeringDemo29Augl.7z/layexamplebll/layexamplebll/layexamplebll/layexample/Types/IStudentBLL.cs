﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using System.Data;


namespace Types
{
    public  interface IStudentBLL
    {

         int AddStudent(IStudentBO objbo);
         void DeleteStudent(string studeid);
         int updateStudent(IStudentBO objbo);
        DataTable ViewStudent();
         List<IStudentBO> ViewStudentList();
         string LoginStudent(ILoginBO objbo);


    }
}
