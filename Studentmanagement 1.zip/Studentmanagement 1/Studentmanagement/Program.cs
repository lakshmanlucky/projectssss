﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studentmanagement
{
    class Program
    {
        

        static void Main(string[] args)
        {
        
            List<pgLearner> lstpgLearner = new List<pgLearner>();
            int choice;
            int studentid;
            string studentname;
                Console.WriteLine("Menu");
            Console.WriteLine("1.Add PGLearner");
            Console.WriteLine("2.Add Marks");
            Console.WriteLine("3.View Marks");
            Console.WriteLine("4.Exit");
            Console.WriteLine("Please enter option");
                
            choice = int.Parse(Console.ReadLine());
            while(choice !=4)
            {
                switch(choice)
                {
                    case 1:    

                          Console.WriteLine("Enter studentid");
                          studentid=int.Parse(Console.ReadLine());

                          Console.WriteLine("Enter studentname");
                          studentname=Console.ReadLine();
                                  
                          pgLearner objstudent=new pgLearner(studentid,studentname);
                          lstpgLearner.Add(objstudent);
                          break;

                    case 2: 
                        
                            Console.WriteLine("Enter studentid");
                            studentid = int.Parse(Console.ReadLine());
                            foreach (pgLearner objpgstudent in lstpgLearner)
                            {

                                if (objpgstudent.LearnerID == studentid)
                                {
                                    objpgstudent.getMarks();

                                }

                            }
                            break;

                    case 3: Console.WriteLine("Enter studentid");
                            studentid = int.Parse(Console.ReadLine());
                            foreach (pgLearner objpgstudent in lstpgLearner)
                            {

                                if (objpgstudent.LearnerID == studentid)
                                {
                                    objpgstudent.printMarks();

                                }

                            }

                            break;
                    

                }

                Console.WriteLine("Menu");
                Console.WriteLine("1.Add PGLearner");
                Console.WriteLine("2.Add Marks");
                Console.WriteLine("3.View Marks");
                Console.WriteLine("4.Exit");
                Console.WriteLine("Please enter option");
                
                choice = int.Parse(Console.ReadLine());
       
                

            }

        }

         


        }
    }

