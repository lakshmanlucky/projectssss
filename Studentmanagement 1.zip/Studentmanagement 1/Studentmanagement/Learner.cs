﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Studentmanagement
{
    abstract class Learner : ILearner
    {
        int learnerid;
        string learnername;
       
        public int LearnerID
        {
            get
            {
                return learnerid;
            }
            set
            {
                learnerid = value;
            }


        }


        public string LearnerName
        {
            get
            {
                return learnername;
            }
            set
            {
                learnername = value;
            }


        }
        
        public abstract void getMarks();
        public abstract void printMarks();

    }
}
